INSERT INTO tarefa (id, titulo, descricao, finalizado, data_Prevista_Finalizacao, data_Finalizacao)
VALUES (1,'Guerra dos tronos', 'era uma vez um lorem', false, '2024-09-04', NULL);

INSERT INTO tarefa (id,titulo, descricao, finalizado, data_Prevista_Finalizacao, data_Finalizacao)
VALUES (2,'carros', 'era uma vez um lorem', false, '2024-07-04', NULL);